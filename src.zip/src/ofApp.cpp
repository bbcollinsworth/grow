#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofSetFrameRate(60);
    ofSetVerticalSync(true);
    ofBackground(255);

    record = false;

}

//--------------------------------------------------------------
void ofApp::update(){

    for (int i = 0; i < trees.size(); i++){

        trees[i].update();
    }

/*
    if (branches.size()<16){
        for (int i=0; i < branches.size(); i++){
            if (branches[i].getSize() == 30){
                ofVec3f branchPoint = branches[i].drawPoint;//+branches[i].startPoint;
                Branch b;
                b.setup(branchPoint,5,ofRandomf()*45,branches[i].angle, branches[i].startPoint,branches.size());
                branches.push_back(b);

            cout << branches.size() << endl;
            cout << branchPoint << endl;

            }
        }
    }

    for (int i=0; i < branches.size(); i++){
        branches[i].update();
    }
    */

}


//--------------------------------------------------------------
void ofApp::draw(){

    ofBackgroundGradient(ofColor (255, 245, 210), ofColor (210, 195, 160));

    for (int i = 0; i < trees.size(); i++){

        trees[i].draw();
    }

/*
    ofPushMatrix();
    for (int i=0; i < branches.size(); i++){
        branches[i].draw(ofColor(60,20,0));
    }
    ofPopMatrix();

*/
    //TO SAVE EVERY FRAME
    if (record == true){
        string frameCount = ofToString(20000+ofGetFrameNum());
        string fileName = "filmImages/" + frameCount + ".png";
        ofSaveScreen(fileName);
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if(key == 'f'){
        ofToggleFullscreen();
    }
    if (key == 's'){
        string frameCount = ofToString(20000+ofGetFrameNum());
        string fileName = "Images/" + frameCount + ".jpg";
        ofSaveScreen(fileName);
    }

    //THIS CREATES A NEW TREE!!
    if(key == 't'){
        ofVec3f treeInit = ofVec3f(0,ofGetHeight()*ofRandom(0.1,0.9),0);
        int angleInit = int(ofRandom(70,130));

        Tree t;
        t.setup(treeInit,angleInit);
        trees.push_back(t);
    }

    //THIS SAVES EVERY FRAME
    if(key == 'r'){
            record = true;
        }

    if(key == 'e'){
            record = false;
    }


}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}
